import api, { unwrap } from "@/lib/api";

import {
  FeaturedServiceResponse,
  PublicServiceResponse,
  SinglePublicServiceResponse,
} from "@/types/public-service/public-service";

export const publicServiceService = {

  async getAll(
    page = 1,
    search = ""
  ): Promise<PublicServiceResponse> {

    const response = await api.get(
      "/public/services",
      {
        params: {
          page,
          search,
          per_page: 12,
        },
      }
    );

    return unwrap<PublicServiceResponse>(
      response
    );
  },

  async featured(): Promise<FeaturedServiceResponse> {

    const response = await api.get(
      "/public/services/featured"
    );

    return unwrap<FeaturedServiceResponse>(
      response
    );
  },

  async show(
    id: number
  ): Promise<SinglePublicServiceResponse> {

    const response = await api.get(
      `/public/services/${id}`
    );

    return unwrap<SinglePublicServiceResponse>(
      response
    );
  },
};