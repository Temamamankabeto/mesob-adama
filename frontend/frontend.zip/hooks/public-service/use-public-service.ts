"use client";

import {
  useQuery,
} from "@tanstack/react-query";

import { publicServiceService } from "@/services/public-service/public-service";

export function usePublicServices(
  page = 1,
  search = ""
) {

  return useQuery({

    queryKey: [
      "public-services",
      page,
      search,
    ],

    queryFn: () =>
      publicServiceService.getAll(
        page,
        search
      ),
  });
}

export function useFeaturedServices() {

  return useQuery({

    queryKey: [
      "featured-public-services",
    ],

    queryFn: () =>
      publicServiceService.featured(),
  });
}

export function usePublicService(
  id: number
) {

  return useQuery({

    queryKey: [
      "public-service",
      id,
    ],

    queryFn: () =>
      publicServiceService.show(id),

    enabled: !!id,
  });
}