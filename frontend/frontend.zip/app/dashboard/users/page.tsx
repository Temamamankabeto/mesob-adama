"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

import {
  useUsers,
  useDeleteUser,
} from "@/hooks/user/useUsers";

import { useToggleUserStatus } from "@/hooks/user/useToggleUserStatus";
import { locationLevelLabel, roleLabel } from "@/config/roles.config";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import { MoreVertical, Search } from "lucide-react";

export default function UsersPage() {
  const router = useRouter();

  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");

  const { data, isLoading } = useUsers(page, search);

  const users = data?.data || [];
  const meta = data?.meta;

  const deleteUser = useDeleteUser();
  const toggleStatus = useToggleUserStatus();

  const handleDelete = (id: number) => {
    if (confirm("Delete user?")) {
      deleteUser.mutate(id);
    }
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Users</h1>
          <p className="text-sm text-muted-foreground">
            Manage users by role and location scope.
          </p>
        </div>

        <Button onClick={() => router.push("/dashboard/users/add")}>
          Add User
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />

            <Input
              placeholder="Search users..."
              value={search}
              onChange={(event) => {
                setSearch(event.target.value);
                setPage(1);
              }}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          {/* count all users */}
          <CardTitle>User List({meta?.total || 0})</CardTitle>
        </CardHeader>

        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>#</TableHead>
                <TableHead>Full Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Level</TableHead>
                <TableHead>City</TableHead>
                <TableHead>Subcity</TableHead>
                <TableHead>Woreda</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-[80px]">Action</TableHead>
              </TableRow>
            </TableHeader>

            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={10} className="py-10 text-center">
                    Loading...
                  </TableCell>
                </TableRow>
              ) : users.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={10} className="py-10 text-center">
                    No users found
                  </TableCell>
                </TableRow>
              ) : (
                users.map((user: any) => (
                  <TableRow key={user.id}>
                    {/* auto increment not use id */}
                    <TableCell>
                      {(meta?.current_page - 1) * meta?.per_page + users.indexOf(user) + 1}
                      </TableCell>
                    <TableCell>{user.name}</TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>{user.phone}</TableCell>

                    <TableCell>
                      {(user.role_names || [user.role]).filter(Boolean).map((role: string) => (
                        <span key={role} className="mr-1 rounded bg-blue-100 px-2 py-1 text-xs text-blue-700">
                          {roleLabel(role)}
                        </span>
                      ))}
                    </TableCell>

                    <TableCell>{locationLevelLabel(user.location_level) || "-"}</TableCell>
                    <TableCell>{user.city?.name || "-"}</TableCell>
                    <TableCell>{user.subcity?.name || "-"}</TableCell>
                    <TableCell>{user.woreda?.name || "-"}</TableCell>

                    <TableCell>
                      <span
                        className={`rounded px-2 py-1 text-xs font-medium ${
                          Boolean(user.is_active)
                            ? "bg-green-100 text-green-700"
                            : "bg-red-100 text-red-700"
                        }`}
                      >
                        {Boolean(user.is_active) ? "Active" : "Disabled"}
                      </span>
                    </TableCell>

                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="h-5 w-5" />
                          </Button>
                        </DropdownMenuTrigger>

                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => router.push(`/dashboard/users/${user.id}`)}>
                            View
                          </DropdownMenuItem>

                          <DropdownMenuItem onClick={() => router.push(`/dashboard/users/${user.id}/edit`)}>
                            Edit
                          </DropdownMenuItem>

                          <DropdownMenuItem onClick={() => router.push(`/dashboard/users/${user.id}/change-password`)}>
                            Change Password
                          </DropdownMenuItem>

                          <DropdownMenuItem onClick={() => toggleStatus.mutate(user.id)}>
                            {user.is_active ? "Disable User" : "Enable User"}
                          </DropdownMenuItem>

                          <DropdownMenuItem className="text-red-600" onClick={() => handleDelete(user.id)}>
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>

          <div className="mt-6 flex items-center justify-between">
            <div className="text-sm text-muted-foreground">
              Showing page {meta?.current_page || 1} of {meta?.last_page || 1}
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                disabled={meta?.current_page === 1}
                onClick={() => setPage((previous) => Math.max(previous - 1, 1))}
              >
                Prev
              </Button>

              <Button
                variant="outline"
                disabled={meta?.current_page === meta?.last_page}
                onClick={() => setPage((previous) => previous + 1)}
              >
                Next
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
