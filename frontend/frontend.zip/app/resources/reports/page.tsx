import { BarChart3, ExternalLink, FileText, TrendingUp } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const powerBiUrl = process.env.NEXT_PUBLIC_POWER_BI_REPORT_URL || "";

export default function ReportsPage() {
  return (
    <main className="min-h-screen bg-slate-50 px-4 py-8 text-[#08214a] md:px-8">
      <section className="mx-auto max-w-7xl space-y-6">
        <div className="rounded-3xl bg-gradient-to-r from-[#06295a] to-[#0758a8] p-8 text-white shadow-xl">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="font-semibold text-emerald-200">Adama MESOB eService</p>
              <h1 className="mt-2 text-3xl font-black md:text-5xl">Power BI Reports Dashboard</h1>
              <p className="mt-3 max-w-3xl text-white/85">Monitor service usage, applications, payments, officer performance, and citizen requests.</p>
            </div>
            <BarChart3 className="h-16 w-16 text-emerald-200" />
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <ReportStat title="Applications" value="Live" icon={FileText} />
          <ReportStat title="Service Performance" value="Tracked" icon={TrendingUp} />
          <ReportStat title="Power BI" value="Embedded" icon={BarChart3} />
        </div>

        <Card className="overflow-hidden rounded-3xl shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Official Analytics Dashboard</CardTitle>
            {powerBiUrl ? <Button asChild><a href={powerBiUrl} target="_blank" rel="noreferrer"><ExternalLink className="mr-2 h-4 w-4" />Open</a></Button> : null}
          </CardHeader>
          <CardContent>
            {powerBiUrl ? (
              <iframe title="Adama MESOB Power BI Report" src={powerBiUrl} className="h-[720px] w-full rounded-2xl border" allowFullScreen />
            ) : (
              <div className="flex h-[520px] items-center justify-center rounded-2xl border border-dashed bg-white text-center">
                <div>
                  <BarChart3 className="mx-auto h-14 w-14 text-[#0758a8]" />
                  <h2 className="mt-4 text-2xl font-black">Power BI report URL is not configured</h2>
                  <p className="mt-2 text-slate-600">Add NEXT_PUBLIC_POWER_BI_REPORT_URL in .env.local or hosting environment.</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </section>
    </main>
  );
}

function ReportStat({ title, value, icon: Icon }: { title: string; value: string; icon: typeof BarChart3 }) {
  return (
    <Card className="rounded-2xl shadow-sm">
      <CardContent className="flex items-center gap-4 p-6">
        <span className="rounded-2xl bg-emerald-100 p-4 text-emerald-700"><Icon className="h-7 w-7" /></span>
        <div><p className="text-sm text-slate-500">{title}</p><h3 className="text-2xl font-black">{value}</h3></div>
      </CardContent>
    </Card>
  );
}
