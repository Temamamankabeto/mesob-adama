"use client";

import Link from "next/link";
import { useMemo, useState } from "react";

import {
  ArrowRight,
  Building2,
  FileSearch,
  Search,
  ShieldCheck,
} from "lucide-react";

import { Input } from "@/components/ui/input";

import { Button } from "@/components/ui/button";

import {
  Card,
  CardContent,
} from "@/components/ui/card";

import { Badge } from "@/components/ui/badge";

import { usePublicServices } from "@/hooks/public-service/use-public-service";

export default function PublicServicesPage() {

  const [page] = useState(1);

  const [search, setSearch] =
    useState("");

  const {
    data,
    isLoading,
    error,
  } = usePublicServices(
    page,
    search
  );

  /*
  |--------------------------------------------------------------------------
  | FIXED SERVICES EXTRACTION
  |--------------------------------------------------------------------------
  */

  const services = useMemo(() => {

    /*
    unwrap() already returns response.data
    so structure becomes:

    {
      success,
      message,
      data: {
        current_page,
        data: [...]
      }
    }
    */

    return (
      data?.data?.data || []
    );

  }, [data]);

  return (
    <div className="min-h-screen bg-background">

      {/* HERO */}
      <section className="border-b border-border bg-muted/30">

        <div className="container mx-auto px-6 py-20">

          <div className="mx-auto max-w-4xl text-center">

            {/* BADGE */}
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 shadow-sm">

              <ShieldCheck className="h-4 w-4 text-primary" />

              <span className="text-sm font-medium text-muted-foreground">
                Public Digital Services
              </span>
            </div>

            {/* TITLE */}
            <h1 className="text-5xl font-black tracking-tight">

              Government Services
            </h1>

            {/* DESCRIPTION */}
            <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-muted-foreground">

              Browse and apply for available digital government services online.
            </p>

            {/* SEARCH */}
            <div className="mx-auto mt-10 max-w-2xl">

              <div className="flex items-center gap-3 rounded-3xl border border-border bg-card p-3 shadow-lg">

                <div className="relative flex-1">

                  <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />

                  <Input
                    placeholder="Search services..."

                    className="h-12 border-0 bg-transparent pl-11 shadow-none focus-visible:ring-0"

                    value={search}

                    onChange={(e) =>
                      setSearch(
                        e.target.value
                      )
                    }
                  />
                </div>

                <Button className="h-12 rounded-2xl px-8">
                  Search
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="py-20">

        <div className="container mx-auto px-6">

          {/* ERROR */}
          {error && (

            <div className="mb-10 rounded-2xl border border-destructive/20 bg-destructive/10 p-5 text-center text-destructive">

              Failed to load services
            </div>
          )}

          {/* LOADING */}
          {isLoading ? (

            <div className="flex justify-center py-20 text-muted-foreground">

              Loading services...
            </div>

          ) : services.length === 0 ? (

            /* EMPTY */
            <div className="flex flex-col items-center justify-center py-20 text-center">

              <div className="mb-5 rounded-3xl bg-primary/10 p-6 text-primary">

                <FileSearch className="h-10 w-10" />
              </div>

              <h2 className="text-2xl font-bold">
                No Services Found
              </h2>

              <p className="mt-3 max-w-md text-muted-foreground">

                No public services are currently available or matched your search.
              </p>
            </div>

          ) : (

            <>
              {/* GRID */}
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">

                {services.map(
                  (service: any) => (

                    <Card
                      key={service.id}
                      className="group overflow-hidden border-border bg-card transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
                    >

                      <CardContent className="p-6">

                        {/* ICON */}
                        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">

                          <Building2 className="h-7 w-7" />
                        </div>

                        {/* TITLE */}
                        <h2 className="mt-6 text-2xl font-semibold">

                          {service.name}
                        </h2>

                        {/* DESCRIPTION */}
                        <p className="mt-4 line-clamp-3 text-sm leading-7 text-muted-foreground">

                          {
                            service.description ||
                            "No description available."
                          }
                        </p>

                        {/* AVAILABILITY */}
                        <div className="mt-5 flex flex-wrap gap-2">

                          {service.availability?.map(
                            (
                              item: string
                            ) => (

                              <Badge
                                key={item}
                                variant="secondary"
                                className="rounded-xl capitalize"
                              >
                                {item}
                              </Badge>
                            )
                          )}
                        </div>

                        {/* FOOTER */}
                        <div className="mt-8 flex items-center justify-between border-t border-border pt-5">

                          <div>

                            <p className="text-xs text-muted-foreground">
                              Service Fee
                            </p>

                            <p className="text-lg font-bold text-primary">

                              ETB {
                                service.service_fee
                              }
                            </p>
                          </div>

                          <Link
                            href={`/public-services/${service.id}`}
                          >

                            <Button className="rounded-xl">

                              View

                              <ArrowRight className="ml-2 h-4 w-4" />
                            </Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>
                  )
                )}
              </div>

              {/* PAGINATION INFO */}
              <div className="mt-10 text-center text-sm text-muted-foreground">

                Showing{" "}
                <span className="font-semibold text-foreground">
                  {services.length}
                </span>{" "}
                services
              </div>
            </>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-border bg-muted/30 py-20">

        <div className="container mx-auto px-6">

          <div className="mx-auto max-w-3xl text-center">

            <div className="mb-5 flex justify-center">

              <div className="rounded-2xl bg-primary/10 p-4 text-primary">

                <FileSearch className="h-6 w-6" />
              </div>
            </div>

            <h2 className="text-4xl font-bold tracking-tight">

              Need Help?
            </h2>

            <p className="mt-5 text-lg leading-8 text-muted-foreground">

              Contact the digital government support center for assistance and guidance.
            </p>

            <div className="mt-8">

              <Link href="/contact">

                <Button className="rounded-xl px-8">
                  Contact Support
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}