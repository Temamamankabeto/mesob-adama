<?php

namespace App\Services;

use App\Models\User;
use App\Support\AppRoles;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Spatie\Permission\Models\Role;

class UserService
{
    public function paginateUsers(array $filters = [], ?User $actor = null): LengthAwarePaginator
    {
        $perPage = max(1, min((int) ($filters['per_page'] ?? 10), 100));
        $search = trim((string) ($filters['search'] ?? ''));
        $status = $filters['status'] ?? null;
        $role = AppRoles::normalize($filters['role'] ?? null);

        $query = User::query()
            ->with(['city', 'subcity', 'woreda', 'roles']);

        if ($actor) {
            $this->applyLocationScope($query, $actor);
        }

        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%")
                    ->orWhere('phone', 'like', "%{$search}%");
            });
        }

        if ($status === 'active') {
            $query->where('is_active', true);
        } elseif ($status === 'disabled') {
            $query->where('is_active', false);
        }

        if ($role) {
            $query->role($role);
        }

        return $query->latest()->paginate($perPage);
    }

    public function transformPaginatedUsers(LengthAwarePaginator $users): array
    {
        return [
            'success' => true,
            'message' => 'Users retrieved successfully',
            'data' => collect($users->items())->map(fn (User $user) => $this->payload($user))->values(),
            'meta' => [
                'current_page' => $users->currentPage(),
                'per_page' => $users->perPage(),
                'total' => $users->total(),
                'last_page' => $users->lastPage(),
            ],
        ];
    }

    public function getUser(int|string $id): User
    {
        return User::with(['city', 'subcity', 'woreda', 'roles'])->findOrFail($id);
    }

    public function getRolesLite()
    {
        return collect(AppRoles::orderedRoleOptions())
            ->map(function (array $roleOption) {
                $role = Role::firstOrCreate([
                    'name' => $roleOption['name'],
                    'guard_name' => 'sanctum',
                ]);

                return [
                    'id' => $role->id,
                    ...$roleOption,
                ];
            })
            ->values();
    }

    public function createUser(array $data, ?User $actor = null): User
    {
        $roleName = AppRoles::normalize($data['role'] ?? null);

        if (!$roleName || !AppRoles::isBuiltin($roleName)) {
            throw ValidationException::withMessages([
                'role' => ['Invalid role selected.'],
            ]);
        }

        $location = $this->normalizeLocationForRole(
            $roleName,
            $data['location_level'] ?? null,
            $data['city_id'] ?? null,
            $data['subcity_id'] ?? null,
            $data['woreda_id'] ?? null
        );

        $this->assertActorCanManageRole($actor, $roleName, $location);

        unset(
            $data['role'],
            $data['location_level'],
            $data['city_id'],
            $data['subcity_id'],
            $data['woreda_id']
        );

        $payload = [
            ...$data,
            ...$location,
            'password' => Hash::make($data['password']),
        ];

        if (array_key_exists('is_active', $data)) {
            $payload['is_active'] = (bool) $data['is_active'];
        } elseif (array_key_exists('status', $data)) {
            $payload['is_active'] = $data['status'] === 'active';
        } else {
            $payload['is_active'] = true;
        }

        $user = User::create($payload);
        $user->assignRole($roleName);

        return $user->load(['city', 'subcity', 'woreda', 'roles']);
    }

    public function updateUser(User $user, array $data, ?User $actor = null): User
    {
        $roleName = AppRoles::normalize($data['role'] ?? optional($user->roles->first())->name);

        if (!$roleName || !AppRoles::isBuiltin($roleName)) {
            throw ValidationException::withMessages([
                'role' => ['Invalid role selected.'],
            ]);
        }

        $location = $this->normalizeLocationForRole(
            $roleName,
            $data['location_level'] ?? null,
            $data['city_id'] ?? null,
            $data['subcity_id'] ?? null,
            $data['woreda_id'] ?? null
        );

        $this->assertActorCanManageRole($actor, $roleName, $location);

        $payload = [
            'name' => $data['name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'gender' => $data['gender'] ?? null,
            'date_of_birth' => $data['date_of_birth'] ?? null,
            'address' => $data['address'] ?? null,
            ...$location,
        ];

        if (!empty($data['password'])) {
            $payload['password'] = Hash::make($data['password']);
        }

        if (array_key_exists('is_active', $data)) {
            $payload['is_active'] = (bool) $data['is_active'];
        } elseif (array_key_exists('status', $data)) {
            $payload['is_active'] = $data['status'] === 'active';
        }

        $user->update($payload);
        $user->syncRoles([$roleName]);

        return $user->fresh(['city', 'subcity', 'woreda', 'roles']);
    }

    public function assignRole(User $user, string $roleName, ?User $actor = null): User
    {
        $roleName = AppRoles::normalize($roleName);

        if (!$roleName || !AppRoles::isBuiltin($roleName)) {
            throw ValidationException::withMessages([
                'role' => ['Invalid role selected.'],
            ]);
        }

        $location = $this->normalizeLocationForRole(
            $roleName,
            AppRoles::levelFromLocation($user->city_id, $user->subcity_id, $user->woreda_id),
            $user->city_id,
            $user->subcity_id,
            $user->woreda_id
        );

        $this->assertActorCanManageRole($actor, $roleName, $location);

        $user->update($location);
        $user->syncRoles([$roleName]);

        return $user->fresh(['city', 'subcity', 'woreda', 'roles']);
    }

    public function toggleUser(User $user): User
    {
        $user->is_active = !$user->is_active;
        $user->save();

        return $user->load(['city', 'subcity', 'woreda', 'roles']);
    }

    public function resetPassword(User $user, string $newPassword): User
    {
        $user->password = Hash::make($newPassword);
        $user->save();

        return $user;
    }

    public function getWaitersLite(?string $search = null)
    {
        $query = User::query()
            ->select('id', 'name')
            ->whereHas('roles', function ($q) {
                $q->whereIn('name', [
                    AppRoles::FRONT_OFFICER,
                    AppRoles::BACK_OFFICER,
                ]);
            });

        $search = trim((string) $search);

        if ($search !== '') {
            $query->where('name', 'like', "%{$search}%");
        }

        return $query->orderBy('name')->get();
    }

    public function updateProfile(User $user, array $data, ?UploadedFile $profileFile = null): User
    {
        $user->name = $data['name'];
        $user->email = $data['email'];
        $user->phone = $data['phone'];

        if (array_key_exists('gender', $data)) {
            $user->gender = $data['gender'];
        }

        if (!empty($data['new_password'])) {
            if (empty($data['old_password'])) {
                throw ValidationException::withMessages([
                    'old_password' => ['Old password is required when setting a new password.'],
                ]);
            }

            if (!Hash::check($data['old_password'], $user->password)) {
                throw ValidationException::withMessages([
                    'old_password' => ['The provided old password is incorrect.'],
                ]);
            }

            $user->password = Hash::make($data['new_password']);
        }

        if ($profileFile) {
            if ($user->profile_image && Storage::disk('public')->exists($user->profile_image)) {
                Storage::disk('public')->delete($user->profile_image);
            }

            $path = $profileFile->store('users/profile-images', 'public');
            $user->profile_image = $path;
        }

        $user->save();

        return $user->load(['city', 'subcity', 'woreda', 'roles']);
    }

    public function deleteUser(User $user, ?int $authId = null): void
    {
        if ($authId && $authId === $user->id) {
            throw ValidationException::withMessages([
                'user' => ['You cannot delete your own account.'],
            ]);
        }

        $user->syncRoles([]);

        if ($user->profile_image && Storage::disk('public')->exists($user->profile_image)) {
            Storage::disk('public')->delete($user->profile_image);
        }

        $user->delete();
    }

    public function changePassword(User $user, string $currentPassword, string $newPassword): void
    {
        if (!Hash::check($currentPassword, $user->password)) {
            throw ValidationException::withMessages([
                'current_password' => ['Current password is incorrect'],
            ]);
        }

        $user->password = Hash::make($newPassword);
        $user->save();
    }

    protected function normalizeLocationForRole(
        string $roleName,
        ?string $locationLevel,
        int|string|null $cityId,
        int|string|null $subcityId,
        int|string|null $woredaId
    ): array {
        if (!AppRoles::isScoped($roleName)) {
            return [
                'city_id' => null,
                'subcity_id' => null,
                'woreda_id' => null,
            ];
        }

        $locationLevel = AppRoles::normalizeLevel($locationLevel)
            ?? AppRoles::levelFromLocation($cityId, $subcityId, $woredaId)
            ?? AppRoles::LEVEL_CITY;

        $cityId = $cityId ? (int) $cityId : null;
        $subcityId = $subcityId ? (int) $subcityId : null;
        $woredaId = $woredaId ? (int) $woredaId : null;

        if (!$cityId) {
            throw ValidationException::withMessages([
                'city_id' => ['City is required for scoped roles.'],
            ]);
        }

        if (in_array($locationLevel, [AppRoles::LEVEL_SUBCITY, AppRoles::LEVEL_WOREDA], true) && !$subcityId) {
            throw ValidationException::withMessages([
                'subcity_id' => ['Subcity is required for this location level.'],
            ]);
        }

        if ($locationLevel === AppRoles::LEVEL_WOREDA && !$woredaId) {
            throw ValidationException::withMessages([
                'woreda_id' => ['Woreda is required for this location level.'],
            ]);
        }

        return match ($locationLevel) {
            AppRoles::LEVEL_CITY => [
                'city_id' => $cityId,
                'subcity_id' => null,
                'woreda_id' => null,
            ],
            AppRoles::LEVEL_SUBCITY => [
                'city_id' => $cityId,
                'subcity_id' => $subcityId,
                'woreda_id' => null,
            ],
            AppRoles::LEVEL_WOREDA => [
                'city_id' => $cityId,
                'subcity_id' => $subcityId,
                'woreda_id' => $woredaId,
            ],
        };
    }

    protected function assertActorCanManageRole(?User $actor, string $targetRole, array $targetLocation): void
    {
        if (!$actor || $actor->hasRole(AppRoles::SUPER_ADMIN)) {
            return;
        }

        if (!$actor->can('users.create') && !$actor->can('users.update') && !$actor->can('users.assign_role')) {
            throw ValidationException::withMessages([
                'role' => ['You do not have permission to manage users.'],
            ]);
        }

        if ($targetRole === AppRoles::SUPER_ADMIN) {
            throw ValidationException::withMessages([
                'role' => ['Only a super admin can manage super admin users.'],
            ]);
        }

        $actorRole = $actor->roles()->pluck('name')->first();

        if ($actorRole === AppRoles::ADMIN && $targetRole === AppRoles::MANAGER) {
            throw ValidationException::withMessages([
                'role' => ['Admins cannot manage manager users.'],
            ]);
        }

        if ($actorRole === AppRoles::ADMIN && $targetRole === AppRoles::ADMIN) {
            throw ValidationException::withMessages([
                'role' => ['Admins cannot manage admin users.'],
            ]);
        }

        $actorLevel = AppRoles::userLevel($actor);

        if (!$actorLevel) {
            return;
        }

        if ($actorLevel === AppRoles::LEVEL_CITY) {
            if ((int) $actor->city_id !== (int) ($targetLocation['city_id'] ?? 0)) {
                throw ValidationException::withMessages([
                    'city_id' => ['User must belong to your city.'],
                ]);
            }

            return;
        }

        if ($actorLevel === AppRoles::LEVEL_SUBCITY) {
            if (
                (int) $actor->city_id !== (int) ($targetLocation['city_id'] ?? 0) ||
                (int) $actor->subcity_id !== (int) ($targetLocation['subcity_id'] ?? 0)
            ) {
                throw ValidationException::withMessages([
                    'subcity_id' => ['User must belong to your subcity.'],
                ]);
            }

            return;
        }

        if ($actorLevel === AppRoles::LEVEL_WOREDA) {
            if (
                (int) $actor->city_id !== (int) ($targetLocation['city_id'] ?? 0) ||
                (int) $actor->subcity_id !== (int) ($targetLocation['subcity_id'] ?? 0) ||
                (int) $actor->woreda_id !== (int) ($targetLocation['woreda_id'] ?? 0)
            ) {
                throw ValidationException::withMessages([
                    'woreda_id' => ['User must belong to your woreda.'],
                ]);
            }
        }
    }

    protected function applyLocationScope($query, User $actor): void
    {
        if ($actor->hasRole(AppRoles::SUPER_ADMIN)) {
            return;
        }

        $level = AppRoles::userLevel($actor);

        if ($level === AppRoles::LEVEL_CITY && $actor->city_id) {
            $query->where('city_id', $actor->city_id);
        }

        if ($level === AppRoles::LEVEL_SUBCITY && $actor->subcity_id) {
            $query->where('city_id', $actor->city_id)
                ->where('subcity_id', $actor->subcity_id);
        }

        if ($level === AppRoles::LEVEL_WOREDA && $actor->woreda_id) {
            $query->where('city_id', $actor->city_id)
                ->where('subcity_id', $actor->subcity_id)
                ->where('woreda_id', $actor->woreda_id);
        }
    }

    protected function payload(User $user): array
    {
        $roleNames = $user->getRoleNames()->values();
        $role = $roleNames->first();

        return [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'phone' => $user->phone,
            'gender' => $user->gender,
            'date_of_birth' => $user->date_of_birth,
            'address' => $user->address,
            'status' => $user->is_active ? 'active' : 'disabled',
            'is_active' => (bool) $user->is_active,
            'role' => $role,
            'role_names' => $roleNames,
            'location_level' => AppRoles::userLevel($user),
            'roles' => $user->roles,
            'city_id' => $user->city_id,
            'subcity_id' => $user->subcity_id,
            'woreda_id' => $user->woreda_id,
            'city' => $user->city,
            'subcity' => $user->subcity,
            'woreda' => $user->woreda,
            'profile_image_url' => $user->profile_image_url,
            'created_at' => $user->created_at,
        ];
    }
}
