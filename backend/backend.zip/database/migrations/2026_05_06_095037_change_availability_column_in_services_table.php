<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run migrations.
     */
    public function up(): void
    {
        Schema::table('services', function (Blueprint $table) {

            $table->json('availability')->change();

        });
    }

    /**
     * Reverse migrations.
     */
    public function down(): void
    {
        Schema::table('services', function (Blueprint $table) {

            $table->string('availability')->change();

        });
    }
};